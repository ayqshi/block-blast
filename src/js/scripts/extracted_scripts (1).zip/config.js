"use strict";
                    Object.defineProperty(e, "__esModule", {
                        value: !0
                    }),
                    e.config = void 0,
                    e.config = {
                        settings: {
                            name: "CAK1324",
                            id_num: 220,
                            suffix: null,
                            platforms: [1, 2, 5, 7, 10, 12],
                            time_limit: -1,
                            tile_size: [80],
                            opt_tile_size: 38,
                            start_level: 4,
                            block_space: 0,
                            play_node: 2,
                            force_cta_step: 1,
                            destroy_pos: [5, -98],
                            destroy_blocks: [0, 0],
                            destroy_blocks_rand: 0,
                            destroy_single_color: 0,
                            d3_texture_div: 20,
                            score_bingo: [1, 3, 6, 10, 15, 21],
                            score_lbl: [null, " Good", " Great", " Excellect", " Amazing", " Unbelievable"],
                            score_base: 10,
                            guide_conf: [{
                                pos: [125, -44],
                                color: 1